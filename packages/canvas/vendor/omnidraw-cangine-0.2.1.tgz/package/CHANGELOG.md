# Changelog

Release notes must keep these sections separate:

## Unreleased

### Public API

- Describe renderer-neutral API additions, changes, and removals.

### Snapshot schema

- State whether schema `1.0.0` remains compatible and list migrations.

### Backend behavior

- Describe rendering, lifecycle, resource, browser, and fallback changes.

### Performance

- Record workload, environment, p50/p95/p99, and regression disposition.

### Packaging

- Record artifact version, SHA-256, dependency/license inventory, and supported
  Bun, TypeScript, Vite, and browser versions.
