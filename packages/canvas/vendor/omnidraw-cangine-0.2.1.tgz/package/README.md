# `@omnidraw/cangine`

Renderer-neutral infinite-cangine with a retained serializable scene,
WebGL2 rendering, geometry and indexed picking, normalized input, text and
resources, HTML portals, SVG export, animation, optional embedded 3D, and
application-owned transient overlays.

```ts
import {
  createInfiniteCanvas,
  IDENTITY_TRANSFORM_2D,
} from "@omnidraw/cangine";

const engine = await createInfiniteCanvas({
  host: document.querySelector("#canvas") as HTMLElement,
  renderProfile: {
    vector2D: "webgl2",
    threeD: "disabled",
    portals: "disabled",
  },
});

engine.scene.transaction((tx) => {
  tx.upsert({
    id: "content",
    kind: "layer",
    parentId: null,
    orderKey: "A",
    transform: IDENTITY_TRANSFORM_2D,
    role: "content",
    coordinateSpace: "world",
  });
});
```

Public entrypoints are:

- `@omnidraw/cangine`
- `@omnidraw/cangine/types`
- `@omnidraw/cangine/geometry`
- `@omnidraw/cangine/testing`
- `@omnidraw/cangine/backend`
- `@omnidraw/cangine/editor` (optional framework-neutral editor kernel)

Deep imports are unsupported. The renderer core does not own application
persistence, collaboration, history, tool policy, or widget business logic.
The optional editor entrypoint provides replaceable tool, command, selection,
and opt-in linear-history policy without changing that core boundary.

The packed artifact is generated from compiled `dist` output. The checked-in
workspace manifest intentionally points to TypeScript source so Bun/Vite
workspace consumers retain engine hot reload.

The compiled package supports native Node ESM on Node `20.19.0` or newer.
Every emitted relative module specifier includes its `.js` suffix, and release
qualification imports all six public entrypoints with native Node and with
Vitest's default external dependency pipeline.

This prerelease package follows semver. While the version is below `1.0.0`,
breaking public API changes increment the minor version and compatible changes
increment the patch version. The public API version and scene snapshot schema
version are independent.

For the full guide and normative behavior, see the repository
`DOCUMENTATION.md` and `spec.md`.
