# Third-party notices

This inventory is generated from the exact installed runtime dependency graph.
License metadata is factual inventory, not legal approval.

| Package | Version | Declared license | Shipped license files |
|---|---:|---|---|
| @swc/helpers | 0.5.23 | Apache-2.0 | LICENSE |
| base64-js | 1.5.1 | MIT | LICENSE |
| bidi-js | 1.0.3 | MIT | LICENSE.txt |
| brotli | 1.3.3 | MIT | missing |
| clone | 2.1.2 | MIT | LICENSE |
| dfa | 1.2.0 | MIT | missing |
| fast-deep-equal | 3.1.3 | MIT | LICENSE |
| fontkit | 2.0.4 | MIT | missing |
| pako | 0.2.9 | MIT | LICENSE |
| perfect-freehand | 1.2.3 | MIT | LICENSE |
| require-from-string | 2.0.2 | MIT | license |
| restructure | 3.0.2 | MIT | LICENSE |
| tess2 | 1.0.0 | SGI-B-2.0 | missing |
| three | 0.185.1 | MIT | LICENSE |
| tiny-inflate | 1.0.3 | MIT | LICENSE |
| tslib | 2.8.1 | 0BSD | LICENSE.txt |
| unicode-properties | 1.4.1 | MIT | LICENSE |
| unicode-trie | 2.0.0 | MIT | LICENSE |
